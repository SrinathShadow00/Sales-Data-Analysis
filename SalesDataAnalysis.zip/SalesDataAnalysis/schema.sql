-- ---------------------------------------------------------------
-- Sales Data Analysis (Superstore-style retail dataset)
-- Engine: SQLite 3
-- Usage : sqlite3 data/superstore.db < schema.sql
-- ---------------------------------------------------------------

DROP TABLE IF EXISTS superstore_sales;

CREATE TABLE superstore_sales (
    row_id        INTEGER PRIMARY KEY,
    order_id      TEXT    NOT NULL,
    order_date    TEXT    NOT NULL,   -- ISO-8601 'YYYY-MM-DD' so strftime() works
    ship_date     TEXT    NOT NULL,
    ship_mode     TEXT    NOT NULL,
    customer_id   TEXT    NOT NULL,
    customer_name TEXT    NOT NULL,
    segment       TEXT    NOT NULL,
    country       TEXT    NOT NULL DEFAULT 'United States',
    city          TEXT    NOT NULL,
    state         TEXT    NOT NULL,
    region        TEXT    NOT NULL,
    product_id    TEXT    NOT NULL,
    category      TEXT    NOT NULL,
    sub_category  TEXT    NOT NULL,
    product_name  TEXT    NOT NULL,
    sales         REAL    NOT NULL,
    quantity      INTEGER NOT NULL,
    discount      REAL    NOT NULL,
    profit        REAL    NOT NULL
);

-- Indexes that back the date-range, regional and category aggregations
CREATE INDEX idx_sales_order_date ON superstore_sales (order_date);
CREATE INDEX idx_sales_region     ON superstore_sales (region);
CREATE INDEX idx_sales_category   ON superstore_sales (category, sub_category);
CREATE INDEX idx_sales_product    ON superstore_sales (product_id);
CREATE INDEX idx_sales_customer   ON superstore_sales (customer_id);
