"""
Generate a realistic Superstore-style retail dataset and load it into SQLite.

The dataset is deterministic (fixed seed), so every run produces the same
rows and therefore the same analysis output. It intentionally contains the
real-world patterns the analysis is designed to surface:

  * West region is the largest revenue contributor
  * Tables and Bookcases are loss-making sub-categories
  * Q4 (Sep/Nov/Dec) shows a seasonal revenue peak
  * Higher discounts are correlated with lower margins

Usage:
    python generate_data.py
"""

from __future__ import annotations

import csv
import os
import random
import sqlite3
from datetime import date, timedelta

SEED = 42
TARGET_ROWS = 9_500          # guarantees a 9,000+ record dataset

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "superstore.db")
CSV_PATH = os.path.join(DATA_DIR, "superstore_sales.csv")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")

# ---------------------------------------------------------------------------
# Product catalogue: sub_category -> (category, gross margin, price band,
#                                     brands, product lines)
# Margins are deliberately negative for Tables/Bookcases so that the
# profit-margin analysis produces genuine loss-making findings.
# ---------------------------------------------------------------------------
SPECS = {
    "Bookcases":    ("Furniture",      -0.030, (130, 700),  ["Bush", "Sauder", "Tennsco", "Riverside"], ["Bookcase", "Library Shelf", "Shelving Unit"]),
    "Chairs":       ("Furniture",       0.130, (120, 600),  ["Hon", "Global", "Iceberg", "Safco"],      ["Task Chair", "Stacking Chair", "Executive Chair"]),
    "Tables":       ("Furniture",      -0.085, (180, 900),  ["Bevis", "Barricks", "Chromcraft", "Luxor"], ["Conference Table", "Folding Table", "Computer Table"]),
    "Furnishings":  ("Furniture",       0.170, (15, 120),   ["Eldon", "Deflect-o", "Rubbermaid"],       ["Shelf Organizer", "Desk Lamp", "Wall Clock"]),

    "Binders":      ("Office Supplies", 0.190, (6, 60),     ["Avery", "Wilson Jones", "Cardinal", "GBC"], ["D-Ring Binder", "View Binder", "Heavy-Duty Binder"]),
    "Paper":        ("Office Supplies", 0.360, (4, 40),     ["Xerox", "HP", "Boise", "Domtar"],         ["Multipurpose Paper", "Copy Paper", "Premium Paper"]),
    "Storage":      ("Office Supplies", 0.130, (20, 180),   ["Sterilite", "Fellowes", "Smead", "Bankers Box"], ["File Box", "Storage Cabinet", "Archive Drawer"]),
    "Art":          ("Office Supplies", 0.240, (3, 30),     ["Sanford", "Newell", "Binney"],            ["Marker Set", "Colored Pencil Set", "Watercolor Pad"]),
    "Appliances":   ("Office Supplies", 0.260, (25, 200),   ["Hoover", "iTouch", "Belkin"],             ["Mini Fridge", "Coffee Maker", "Air Purifier"]),
    "Labels":       ("Office Supplies", 0.310, (4, 25),     ["Avery", "Avery Dennison", "Smead"],       ["Address Label", "Shipping Label", "File Folder Label"]),

    "Phones":       ("Technology",      0.210, (150, 1200), ["Apple", "Samsung", "Cisco", "Motorola"],  ["Smartphone", "IP Phone", "Conference Phone"]),
    "Machines":     ("Technology",      0.050, (300, 1900), ["Canon", "Epson", "Brother", "HP"],        ["Label Printer", "Card Machine", "Fax Machine"]),
    "Accessories":  ("Technology",      0.230, (25, 300),   ["Logitech", "Belkin", "Kensington"],       ["Wireless Mouse", "USB Hub", "Keyboard"]),
    "Copiers":      ("Technology",      0.370, (400, 2200), ["Canon", "Xerox", "HP", "Sharp"],          ["Color Copier", "Multifunction Copier"]),
}

REGIONS = {
    "West":    [("Los Angeles", "California"), ("Seattle", "Washington"), ("Denver", "Colorado"),
                ("Phoenix", "Arizona"), ("Portland", "Oregon"), ("San Francisco", "California")],
    "East":    [("New York City", "New York"), ("Philadelphia", "Pennsylvania"), ("Boston", "Massachusetts"),
                ("Baltimore", "Maryland"), ("Newark", "New Jersey")],
    "Central": [("Chicago", "Illinois"), ("Houston", "Texas"), ("Dallas", "Texas"),
                ("Columbus", "Ohio"), ("Detroit", "Michigan")],
    "South":   [("Atlanta", "Georgia"), ("Miami", "Florida"), ("Charlotte", "North Carolina"),
                ("Nashville", "Tennessee"), ("New Orleans", "Louisiana")],
}
REGION_WEIGHTS = {"West": 0.33, "East": 0.28, "Central": 0.23, "South": 0.16}

SEGMENTS = [("Consumer", 0.52), ("Corporate", 0.30), ("Home Office", 0.18)]
SHIP_MODES = [("Standard Class", 0.60), ("Second Class", 0.20), ("First Class", 0.15), ("Same Day", 0.05)]

# Month-of-year seasonality multipliers: Q4 peak, Jan/Feb trough
MONTH_WEIGHTS = {1: 0.75, 2: 0.72, 3: 0.95, 4: 0.90, 5: 0.95, 6: 1.00,
                 7: 0.92, 8: 0.95, 9: 1.25, 10: 1.00, 11: 1.35, 12: 1.30}

DISCOUNTS = [(0.00, 0.35), (0.10, 0.20), (0.15, 0.12), (0.20, 0.15),
             (0.30, 0.08), (0.40, 0.06), (0.50, 0.04)]

# Order quantity profiles: nobody buys nine copiers in one line item, but
# binders and labels sell in bulk. This keeps the revenue mix plausible.
HIGH_TICKET = {"Copiers", "Machines", "Tables", "Bookcases", "Phones"}
MID_TICKET = {"Chairs", "Furnishings", "Storage", "Appliances", "Accessories"}
QTY_PROFILES = {
    "high": ([1, 2, 3], [72, 20, 8]),
    "mid":  ([1, 2, 3, 4, 5], [42, 25, 15, 10, 8]),
    "low":  ([1, 2, 3, 4, 5, 6, 7, 8, 9], [30, 22, 16, 11, 8, 5, 4, 2, 2]),
}


def quantity_profile(sub_category: str):
    if sub_category in HIGH_TICKET:
        return QTY_PROFILES["high"]
    if sub_category in MID_TICKET:
        return QTY_PROFILES["mid"]
    return QTY_PROFILES["low"]

FIRST_NAMES = ["Aaron", "Alice", "Amy", "Andrew", "Angela", "Anna", "Barbara", "Ben", "Beth", "Brian",
               "Carlos", "Carol", "Catherine", "Charles", "Christine", "Daniel", "David", "Diana", "Donald",
               "Emily", "Eric", "Frank", "George", "Grace", "Helen", "Jacob", "James", "Jane", "Jason",
               "Jennifer", "Jessica", "John", "Karen", "Kevin", "Laura", "Linda", "Lisa", "Mark", "Mary",
               "Matthew", "Michael", "Michelle", "Nancy", "Nathan", "Nicole", "Patricia", "Paul", "Peter",
               "Rachel", "Rebecca", "Richard", "Robert", "Sandra", "Sarah", "Scott", "Sharon", "Steven",
               "Susan", "Thomas", "William"]
LAST_NAMES = ["Adams", "Allen", "Anderson", "Baker", "Bennett", "Brooks", "Brown", "Campbell", "Carter",
              "Clark", "Coleman", "Collins", "Cook", "Cooper", "Cox", "Davis", "Edwards", "Evans", "Fisher",
              "Foster", "Garcia", "Gibson", "Gonzalez", "Gray", "Green", "Hall", "Harris", "Hayes",
              "Henderson", "Hill", "Howard", "Hughes", "Jackson", "James", "Jenkins", "Johnson", "Jones",
              "Kelly", "King", "Lee", "Lewis", "Long", "Lopez", "Martin", "Martinez", "Miller", "Mitchell",
              "Moore", "Morgan", "Morris", "Murphy", "Nelson", "Parker", "Patterson", "Perez", "Perry",
              "Peterson", "Phillips", "Powell", "Price", "Reed", "Richardson", "Rivera", "Roberts",
              "Robinson", "Rodriguez", "Rogers", "Ross", "Russell", "Sanders", "Scott", "Simmons", "Smith",
              "Stewart", "Sullivan", "Taylor", "Thomas", "Thompson", "Turner", "Walker", "Ward", "Watson",
              "White", "Williams", "Wilson", "Wood", "Wright", "Young"]

YEARS = [2021, 2022, 2023, 2024]


def weighted_choice(rng: random.Random, pairs):
    """Return a value from [(value, weight), ...]."""
    values = [p[0] for p in pairs]
    weights = [p[1] for p in pairs]
    return rng.choices(values, weights=weights, k=1)[0]


def build_catalog(rng: random.Random):
    """Create a fixed catalogue of 80+ products with stable prices."""
    catalog = []
    product_seq = 1
    for sub_category, (category, margin, price_band, brands, lines) in SPECS.items():
        combos = [(b, line) for b in brands for line in lines]
        rng.shuffle(combos)
        for brand, line in combos[:8]:
            catalog.append({
                "product_id": f"P-{product_seq:04d}",
                "product_name": f"{brand} {line}",
                "category": category,
                "sub_category": sub_category,
                "unit_price": round(rng.uniform(*price_band), 2),
                "margin": margin,
                "popularity": round(rng.uniform(0.35, 3.0), 3),
            })
            product_seq += 1
    return catalog


def build_customers(rng: random.Random, count: int = 900):
    customers = []
    seen = set()
    for i in range(1, count + 1):
        while True:
            name = f"{rng.choice(FIRST_NAMES)} {rng.choice(LAST_NAMES)}"
            if name not in seen:
                seen.add(name)
                break
        customers.append({
            "customer_id": f"CUS-{i:05d}",
            "customer_name": name,
            "segment": weighted_choice(rng, SEGMENTS),
        })
    return customers


def next_order_date(rng: random.Random) -> date:
    year = rng.choice(YEARS)
    month = rng.choices(list(MONTH_WEIGHTS), weights=list(MONTH_WEIGHTS.values()), k=1)[0]
    day = rng.randint(1, 28)
    return date(year, month, day)


def generate_rows(rng: random.Random, catalog, customers):
    rows = []
    order_seq = 0
    rows_per_order_weights = [(1, 0.42), (2, 0.26), (3, 0.16), (4, 0.10), (5, 0.06)]

    products = [p for p in catalog]
    product_weights = [p["popularity"] for p in products]

    while len(rows) < TARGET_ROWS:
        order_seq += 1
        customer = rng.choice(customers)
        region = weighted_choice(rng, list(REGION_WEIGHTS.items()))
        city, state = rng.choice(REGIONS[region])
        order_date = next_order_date(rng)
        ship_date = order_date + timedelta(days=rng.choice([2, 3, 4, 5, 6, 7]))
        ship_mode = weighted_choice(rng, SHIP_MODES)
        order_id = f"CA-{order_date.year}-{order_seq:06d}"

        for _ in range(weighted_choice(rng, rows_per_order_weights)):
            product = rng.choices(products, weights=product_weights, k=1)[0]
            qty_values, qty_weights = quantity_profile(product["sub_category"])
            quantity = rng.choices(qty_values, weights=qty_weights, k=1)[0]
            discount = weighted_choice(rng, DISCOUNTS)

            sales = round(quantity * product["unit_price"] * (1 - discount), 2)
            # Margin erodes with discount; noise keeps it from being perfectly linear.
            profit = sales * (product["margin"] - discount * 0.65)
            profit += rng.gauss(0, max(sales * 0.02, 0.5))

            rows.append((
                len(rows) + 1,
                order_id,
                order_date.isoformat(),
                ship_date.isoformat(),
                ship_mode,
                customer["customer_id"],
                customer["customer_name"],
                customer["segment"],
                "United States",
                city,
                state,
                region,
                product["product_id"],
                product["category"],
                product["sub_category"],
                product["product_name"],
                sales,
                quantity,
                discount,
                round(profit, 2),
            ))
    return rows


def write_sqlite(rows) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    connection = sqlite3.connect(DB_PATH)
    try:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as schema_file:
            connection.executescript(schema_file.read())

        connection.executemany(
            """INSERT INTO superstore_sales (
                   row_id, order_id, order_date, ship_date, ship_mode,
                   customer_id, customer_name, segment, country, city, state,
                   region, product_id, category, sub_category, product_name,
                   sales, quantity, discount, profit)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            rows,
        )
        connection.commit()
    finally:
        connection.close()


def write_csv(rows) -> None:
    headers = ["row_id", "order_id", "order_date", "ship_date", "ship_mode",
               "customer_id", "customer_name", "segment", "country", "city",
               "state", "region", "product_id", "category", "sub_category",
               "product_name", "sales", "quantity", "discount", "profit"]
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(headers)
        writer.writerows(rows)


def main() -> None:
    rng = random.Random(SEED)
    catalog = build_catalog(rng)
    customers = build_customers(rng)
    rows = generate_rows(rng, catalog, customers)

    write_sqlite(rows)
    write_csv(rows)

    revenue = sum(r[16] for r in rows)
    profit = sum(r[19] for r in rows)
    orders = len({r[1] for r in rows})

    print(f"Rows generated     : {len(rows):,}")
    print(f"Distinct orders    : {orders:,}")
    print(f"Products           : {len(catalog):,}")
    print(f"Customers          : {len(customers):,}")
    print(f"Total revenue      : ${revenue:,.2f}")
    print(f"Total profit       : ${profit:,.2f}")
    print(f"Overall margin     : {profit / revenue * 100:.2f}%")
    print(f"Database           : {DB_PATH}")
    print(f"CSV export         : {CSV_PATH}")


if __name__ == "__main__":
    main()
