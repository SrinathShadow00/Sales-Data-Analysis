-- =====================================================================
-- Sales Data Analysis — analysis queries
-- Run:  python run_analysis.py          (pretty-printed to console)
--   or: sqlite3 data/superstore.db < queries/analysis.sql
-- =====================================================================

-- >>> Q1 | Overall business KPIs
SELECT COUNT(DISTINCT order_id)                       AS orders,
       COUNT(*)                                       AS line_items,
       ROUND(SUM(sales), 2)                           AS revenue,
       ROUND(SUM(profit), 2)                          AS profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2)     AS margin_pct,
       ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2) AS avg_order_value,
       ROUND(AVG(discount) * 100, 2)                  AS avg_discount_pct
FROM superstore_sales;

-- >>> Q2 | Top 10 products by revenue, with revenue share (window function)
WITH product_totals AS (
    SELECT product_name,
           category,
           sub_category,
           SUM(sales)  AS revenue,
           SUM(profit) AS profit,
           SUM(quantity) AS units
    FROM superstore_sales
    GROUP BY product_name, category, sub_category
),
ranked AS (
    SELECT *,
           ROUND(revenue * 100.0 / SUM(revenue) OVER (), 2) AS revenue_share_pct,
           RANK() OVER (ORDER BY revenue DESC)              AS revenue_rank
    FROM product_totals
)
SELECT revenue_rank,
       product_name,
       category,
       sub_category,
       ROUND(revenue, 2) AS revenue,
       ROUND(profit, 2)  AS profit,
       units,
       revenue_share_pct
FROM ranked
WHERE revenue_rank <= 10
ORDER BY revenue_rank;

-- >>> Q3 | Monthly revenue trend with month-over-month growth (LAG)
WITH monthly AS (
    SELECT strftime('%Y-%m', order_date) AS month,
           SUM(sales)  AS revenue,
           SUM(profit) AS profit,
           COUNT(DISTINCT order_id) AS orders
    FROM superstore_sales
    GROUP BY month
)
SELECT month,
       ROUND(revenue, 2) AS revenue,
       ROUND(profit, 2)  AS profit,
       orders,
       ROUND(revenue - LAG(revenue) OVER (ORDER BY month), 2) AS mom_change,
       ROUND((revenue - LAG(revenue) OVER (ORDER BY month)) * 100.0
             / LAG(revenue) OVER (ORDER BY month), 2)          AS mom_growth_pct
FROM monthly
ORDER BY month;

-- >>> Q4 | Seasonality: average revenue by month-of-year (peak detection)
WITH year_month AS (
    SELECT strftime('%Y', order_date)                    AS year,
           CAST(strftime('%m', order_date) AS INTEGER)   AS month_num,
           SUM(sales)                                    AS revenue
    FROM superstore_sales
    GROUP BY year, month_num
),
month_stats AS (
    SELECT month_num,
           AVG(revenue) AS avg_revenue
    FROM year_month
    GROUP BY month_num
)
SELECT month_num,
       CASE month_num WHEN 1 THEN 'Jan' WHEN 2 THEN 'Feb' WHEN 3 THEN 'Mar'
                      WHEN 4 THEN 'Apr' WHEN 5 THEN 'May' WHEN 6 THEN 'Jun'
                      WHEN 7 THEN 'Jul' WHEN 8 THEN 'Aug' WHEN 9 THEN 'Sep'
                      WHEN 10 THEN 'Oct' WHEN 11 THEN 'Nov' WHEN 12 THEN 'Dec' END AS month_name,
       ROUND(avg_revenue, 2) AS avg_revenue,
       ROUND(avg_revenue * 100.0 / (SELECT AVG(avg_revenue) FROM month_stats), 1) AS index_vs_avg
FROM month_stats
ORDER BY month_num;

-- >>> Q5 | Quarterly revenue and profit by year
SELECT strftime('%Y', order_date) AS year,
       'Q' || ((CAST(strftime('%m', order_date) AS INTEGER) - 1) / 3 + 1) AS quarter,
       ROUND(SUM(sales), 2)                            AS revenue,
       ROUND(SUM(profit), 2)                           AS profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2)      AS margin_pct
FROM superstore_sales
GROUP BY year, quarter
ORDER BY year, quarter;

-- >>> Q6 | Profit margin by sub-category (loss-making categories flagged)
SELECT category,
       sub_category,
       ROUND(SUM(sales), 2)                       AS revenue,
       ROUND(SUM(profit), 2)                      AS profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2) AS margin_pct,
       SUM(quantity)                              AS units,
       CASE WHEN SUM(profit) < 0 THEN 'LOSS' ELSE 'PROFIT' END AS status
FROM superstore_sales
GROUP BY category, sub_category
ORDER BY margin_pct ASC;

-- >>> Q7 | Loss-making products (ranked by total loss)
WITH product_totals AS (
    SELECT product_name,
           category,
           sub_category,
           SUM(sales)    AS revenue,
           SUM(profit)   AS profit,
           SUM(quantity) AS units,
           AVG(discount) AS avg_discount
    FROM superstore_sales
    GROUP BY product_name, category, sub_category
)
SELECT product_name,
       category,
       sub_category,
       ROUND(revenue, 2)                        AS revenue,
       ROUND(profit, 2)                         AS profit,
       ROUND(profit * 100.0 / revenue, 2)       AS margin_pct,
       units,
       ROUND(avg_discount * 100, 1)             AS avg_discount_pct
FROM product_totals
WHERE profit < 0
ORDER BY profit ASC
LIMIT 15;

-- >>> Q8 | Regional segmentation: revenue, profit, share and rank
SELECT region,
       COUNT(DISTINCT order_id)                              AS orders,
       ROUND(SUM(sales), 2)                                  AS revenue,
       ROUND(SUM(profit), 2)                                 AS profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2)            AS margin_pct,
       ROUND(SUM(sales) * 100.0
             / (SELECT SUM(sales) FROM superstore_sales), 2) AS revenue_share_pct,
       RANK() OVER (ORDER BY SUM(sales) DESC)                AS revenue_rank
FROM superstore_sales
GROUP BY region
ORDER BY revenue_rank;

-- >>> Q9 | Region x category matrix (% of each region's revenue)
WITH region_category AS (
    SELECT region,
           category,
           SUM(sales)  AS revenue,
           SUM(profit) AS profit
    FROM superstore_sales
    GROUP BY region, category
)
SELECT region,
       category,
       ROUND(revenue, 2) AS revenue,
       ROUND(profit, 2)  AS profit,
       ROUND(revenue * 100.0 / SUM(revenue) OVER (PARTITION BY region), 2) AS pct_of_region
FROM region_category
ORDER BY region, revenue DESC;

-- >>> Q10 | Discount bands vs profitability
WITH banded AS (
    SELECT CASE WHEN discount = 0            THEN '1. 0%'
                WHEN discount <= 0.10        THEN '2. 1-10%'
                WHEN discount <= 0.20        THEN '3. 11-20%'
                WHEN discount <= 0.30        THEN '4. 21-30%'
                ELSE                              '5. 31%+' END AS discount_band,
           discount,
           sales,
           profit
    FROM superstore_sales
)
SELECT discount_band,
       COUNT(*)                                   AS line_items,
       ROUND(SUM(sales), 2)                       AS revenue,
       ROUND(SUM(profit), 2)                      AS profit,
       ROUND(SUM(profit) * 100.0 / SUM(sales), 2) AS margin_pct
FROM banded
GROUP BY discount_band
ORDER BY discount_band;

-- >>> Q11 | Year-over-year revenue growth by region
WITH yearly AS (
    SELECT strftime('%Y', order_date) AS year,
           region,
           SUM(sales) AS revenue
    FROM superstore_sales
    GROUP BY year, region
)
SELECT year,
       region,
       ROUND(revenue, 2) AS revenue,
       ROUND((revenue - LAG(revenue) OVER (PARTITION BY region ORDER BY year)) * 100.0
             / LAG(revenue) OVER (PARTITION BY region ORDER BY year), 2) AS yoy_growth_pct
FROM yearly
ORDER BY region, year;

-- >>> Q12 | Pareto: products needed to reach 80% of revenue
WITH product_totals AS (
    SELECT product_name,
           SUM(sales) AS revenue
    FROM superstore_sales
    GROUP BY product_name
),
cumulative AS (
    SELECT product_name,
           revenue,
           SUM(revenue) OVER (ORDER BY revenue DESC
                              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_revenue,
           SUM(revenue) OVER ()                                                 AS total_revenue,
           ROW_NUMBER() OVER (ORDER BY revenue DESC)                            AS product_rank
    FROM product_totals
)
SELECT product_rank,
       product_name,
       ROUND(revenue, 2)                                    AS revenue,
       ROUND(running_revenue * 100.0 / total_revenue, 2)    AS cumulative_pct
FROM cumulative
WHERE running_revenue * 100.0 / total_revenue <= 80
ORDER BY product_rank;
