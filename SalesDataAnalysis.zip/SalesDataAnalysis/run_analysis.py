"""
Run every query in queries/analysis.sql against data/superstore.db and print
the results as formatted tables.

Usage:
    python run_analysis.py              # print to console
    python run_analysis.py --save       # also write results/analysis_output.txt
"""

from __future__ import annotations

import io
import os
import re
import sqlite3
import sys
from contextlib import redirect_stdout

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "superstore.db")
SQL_PATH = os.path.join(BASE_DIR, "queries", "analysis.sql")
OUT_DIR = os.path.join(BASE_DIR, "results")
OUT_PATH = os.path.join(OUT_DIR, "analysis_output.txt")

QUERY_MARKER = re.compile(r"^-- >>> (Q\d+) \| (.+)$", re.MULTILINE)


def split_queries(sql_text: str):
    """Split the .sql file into (query_id, title, statement) tuples."""
    markers = list(QUERY_MARKER.finditer(sql_text))
    queries = []
    for index, match in enumerate(markers):
        start = match.end()
        end = markers[index + 1].start() if index + 1 < len(markers) else len(sql_text)
        body = "\n".join(
            line for line in sql_text[start:end].splitlines()
            if not line.strip().startswith("--")
        )
        body = body.strip().rstrip(";").strip()
        if body:
            queries.append((match.group(1), match.group(2).strip(), body))
    return queries


def format_table(headers, rows) -> str:
    """Render rows as a fixed-width text table."""
    columns = [str(h) for h in headers]
    data = [["" if value is None else str(value) for value in row] for row in rows]
    widths = [len(c) for c in columns]
    for row in data:
        for i, value in enumerate(row):
            widths[i] = max(widths[i], len(value))

    separator = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    lines = [separator,
             "| " + " | ".join(c.ljust(widths[i]) for i, c in enumerate(columns)) + " |",
             separator]
    for row in data:
        lines.append("| " + " | ".join(v.ljust(widths[i]) for i, v in enumerate(row)) + " |")
    if data:
        lines.append(separator)
    return "\n".join(lines)


def render(connection: sqlite3.Connection, queries) -> str:
    """Execute each query and return the fully formatted report."""
    cursor = connection.cursor()
    total_products = cursor.execute(
        "SELECT COUNT(DISTINCT product_name) FROM superstore_sales"
    ).fetchone()[0]

    buffer = io.StringIO()
    with redirect_stdout(buffer):
        for query_id, title, statement in queries:
            cursor.execute(statement)
            headers = [d[0] for d in cursor.description or []]
            rows = cursor.fetchall()

            print("=" * 100)
            print(f"{query_id}  {title}")
            print("=" * 100)

            if query_id == "Q3" and len(rows) > 12:
                print(f"(showing the 12 most recent months of {len(rows)} total)")
                rows = rows[-12:]
            elif query_id == "Q12":
                print(f"({len(rows)} of {total_products} products generate ~80% of revenue)")
            elif query_id == "Q7":
                print(f"(top {len(rows)} loss-making products)")

            print(format_table(headers, rows))
            print()
    return buffer.getvalue()


def main() -> None:
    if not os.path.exists(DB_PATH):
        raise SystemExit("Database not found. Run `python generate_data.py` first.")

    with open(SQL_PATH, "r", encoding="utf-8") as sql_file:
        queries = split_queries(sql_file.read())

    connection = sqlite3.connect(DB_PATH)
    try:
        report = render(connection, queries)
    finally:
        connection.close()

    print(report, end="")

    if "--save" in sys.argv:
        os.makedirs(OUT_DIR, exist_ok=True)
        with open(OUT_PATH, "w", encoding="utf-8") as out_file:
            out_file.write(report)
        print(f"Saved: {OUT_PATH}")


if __name__ == "__main__":
    main()
