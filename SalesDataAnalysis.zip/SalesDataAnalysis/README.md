# Sales Data Analysis (SQL / SQLite)

Exploratory analysis of a **9,500-row retail sales dataset** (4,452 orders, 112 products,
900 customers, 2021–2024) using pure SQL in SQLite. The project answers four business
questions: which products drive revenue, how revenue moves over time, where the business
loses money, and how performance differs by region and category.

Everything runs on the Python standard library and the `sqlite3` CLI — no dependencies,
no external database server.

---

## Dataset

| Property | Value |
|---|---|
| Grain | One row per order line item |
| Rows | 9,500 |
| Orders | 4,452 |
| Products | 112 across 14 sub-categories and 3 categories |
| Customers | 900 |
| Period | Jan 2021 – Dec 2024 |
| Total revenue | $4,339,046.59 |
| Total profit | $457,125.45 (10.54% margin) |

The data is **synthetically generated with a fixed seed**, so results are reproducible.
It is modelled on the well-known Superstore dataset and deliberately encodes realistic
patterns (a seasonal Q4 peak, loss-making furniture lines, discount-driven margin erosion)
so the analysis produces genuine findings rather than uniform noise.

Two files are produced by the generator:

- `data/superstore.db` — SQLite database used by every query
- `data/superstore_sales.csv` — the same rows as flat CSV (for Excel / BI tools)

---

## Project structure

```
SalesDataAnalysis/
├── schema.sql              # DDL: table definition + 5 indexes
├── generate_data.py        # seeded generator -> SQLite + CSV
├── run_analysis.py         # executes every query, prints text tables
├── queries/
│   └── analysis.sql        # 12 analysis queries (source of truth)
├── results/
│   └── analysis_output.txt # captured output of the full run
└── data/                   # generated (db + csv)
```

## Quick start

```bash
# 1. Build the database (creates data/superstore.db and data/superstore_sales.csv)
python generate_data.py

# 2. Run all 12 queries and print formatted tables
python run_analysis.py

# 3. Optional: also save the report to results/analysis_output.txt
python run_analysis.py --save
```

Or run the SQL directly without Python:

```bash
sqlite3 data/superstore.db < queries/analysis.sql
```

---

## Schema

```sql
CREATE TABLE superstore_sales (
    row_id        INTEGER PRIMARY KEY,
    order_id      TEXT    NOT NULL,
    order_date    TEXT    NOT NULL,   -- ISO-8601 'YYYY-MM-DD'
    ship_date     TEXT    NOT NULL,
    ship_mode     TEXT    NOT NULL,
    customer_id   TEXT    NOT NULL,
    customer_name TEXT    NOT NULL,
    segment       TEXT    NOT NULL,   -- Consumer / Corporate / Home Office
    country       TEXT    NOT NULL,
    city          TEXT    NOT NULL,
    state         TEXT    NOT NULL,
    region        TEXT    NOT NULL,   -- West / East / Central / South
    product_id    TEXT    NOT NULL,
    category      TEXT    NOT NULL,   -- Furniture / Office Supplies / Technology
    sub_category  TEXT    NOT NULL,
    product_name  TEXT    NOT NULL,
    sales         REAL    NOT NULL,
    quantity      INTEGER NOT NULL,
    discount      REAL    NOT NULL,
    profit        REAL    NOT NULL
);
```

Indexes on `order_date`, `region`, `(category, sub_category)`, `product_id` and
`customer_id` support the date-range and segmentation aggregations.

---

## Analysis queries

| # | Question | SQL techniques |
|---|---|---|
| Q1 | Overall KPIs (revenue, profit, AOV, margin) | Aggregates, `COUNT(DISTINCT)` |
| Q2 | Top 10 products by revenue + share | **CTE**, `RANK()`, `SUM() OVER ()` |
| Q3 | Monthly trend with month-over-month growth | **CTE**, `strftime`, `LAG()` |
| Q4 | Seasonality by month-of-year (peak detection) | Nested CTEs, year-month rollup, index vs. average |
| Q5 | Quarterly revenue and margin by year | Date extraction, `GROUP BY` |
| Q6 | Profit margin by sub-category, losses flagged | `CASE` classification |
| Q7 | Loss-making products ranked by total loss | **CTE**, `HAVING`-style filter via `WHERE` |
| Q8 | Regional revenue, profit, share and rank | `RANK()`, scalar subquery |
| Q9 | Region × category matrix (% of region) | **CTE** + `SUM() OVER (PARTITION BY)` |
| Q10 | Discount bands vs. profitability | `CASE` bucketing |
| Q11 | Year-over-year growth by region | **CTE**, `LAG() OVER (PARTITION BY)` |
| Q12 | Pareto: products producing 80% of revenue | Cumulative window `ROWS UNBOUNDED PRECEDING` |

---

## Key findings

**Revenue is concentrated.** The top 10 products account for **43.3% of total revenue**, and
just **34 of 112 products (30%) generate roughly 80%** of sales. Copiers
(*Sharp*, *Canon*, *Xerox*) dominate the top ranks.

**Two sub-categories destroy value.** Furniture is carried by *Tables* at **−15.55% margin
(−$73,310)** and *Bookcases* at **−10.67% (−$27,643)**, with *Machines* also negative at
**−2.93%**. These three lines carry **$1.44M of revenue while losing $121,623 net**.

**Revenue is highly seasonal.** November runs at **141% of the average month**, with
December (123%) and September (125%) also peaking; February is the trough at **69%**.
The Q4 window consistently outperforms the rest of the year.

**Discounting is the direct cause of the losses.** Margin falls monotonically with
discount depth:

| Discount band | Line items | Margin |
|---|---|---|
| 0% | 3,243 | +17.74% |
| 1–10% | 1,910 | +11.84% |
| 11–20% | 2,593 | +7.26% |
| 21–30% | 778 | −0.61% |
| 31%+ | 976 | −10.37% |

Every order line discounted above ~21% is unprofitable on average.

**West is the largest market.** West generates **$1,448,468 (33.4% of revenue)** at a
10.7% margin, ahead of East (28.2%), Central (22.0%) and South (16.5%). Technology is the
top category in every region at 59–61% of regional revenue, while Furniture is the only
category that loses money in all four regions.

---

## Mapping to resume bullets

| Resume claim | Evidence in this repo |
|---|---|
| "Analyzed 9,000+ records to identify top-performing products" | Q2 — top 10 products with revenue share |
| "Aggregations, CTEs and date functions to track monthly trends" | Q3, Q4, Q5 — `strftime`, `LAG`, nested CTEs |
| "Identified losses by calculating profit margins across categories" | Q6, Q7, Q10 |
| "Segmented sales by region and category, West highest revenue" | Q8, Q9, Q11 |
| "Optimized insights" (bonus) | Q12 Pareto analysis, 5 indexes on hot columns |

## Design notes

- **Deterministic generation** (`SEED = 42`) means anyone can reproduce the exact numbers.
- **Quantity profiles by price tier** keep the data plausible — no nine-copier orders, but
  labels and binders sell in bulk.
- **Profit is modelled as `sales × (margin − discount × 0.65)`** so discounting erodes
  margin in a controlled, realistic way rather than randomly.
- Queries are stored in `queries/analysis.sql` as the single source of truth; the Python
  runner only formats output, so the SQL can be pasted into any SQLite client.
